<?php

namespace ACP\Editing\Model\Post;

use ACP\Editing\Model;

/**
 * @deprecated 4.7
 */
class Title extends Model\Post\TitleRaw {

}