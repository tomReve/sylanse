<?php

namespace ACP\Editing\Model\Comment;

use ACP\Editing\Model;

/**
 * @deprecated 4.5
 */
class Excerpt extends Model\Comment\Comment {

}