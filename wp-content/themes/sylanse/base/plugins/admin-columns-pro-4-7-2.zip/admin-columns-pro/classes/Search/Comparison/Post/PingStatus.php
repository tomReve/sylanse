<?php

namespace ACP\Search\Comparison\Post;

class PingStatus extends CommentStatus {

	protected function get_field() {
		return 'ping_status';
	}

}